<html>
<head>
    <title>Lista de empresas</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<?php
require_once("../dao/empresasDao.php");
$dao=new empresasDao();
$dados=$dao->listaGeral();
echo "<table border=1>";
foreach($dados as $dado){
    echo "<tr>";
    echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['nome']}</td>";
echo "<td>{$dado['descricao']}</td>";
echo "<td>{$dado['telefone']}</td>";
echo "<td>{$dado['email']}</td>";
echo "<td>{$dado['id_tipo']}</td>";
echo "<td>{$dado['id_cidade']}</td>";

    echo "<td><a href='../control/empresasControl.php?id={$dado['id']}&a=2'>Excluir</a></td>";
    echo "<td><a href='../view/empresas.php?id={$dado['id']}'>Alterar</a></td>";
    echo "</tr>";
}
echo "</table>";
?>
</body>
</html>