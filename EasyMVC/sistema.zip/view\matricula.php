<html>
    <head>
        <title>Cadastro de matricula</title>
        <link rel="stylesheet" href="../../css/estilos.css">
    </head>
    <body>
        <form method="POST" action="#">
            <label for='campo_id'>id</label>
<input type='number' name='campo_id'><br>
<label for='campo_aluno_id'>aluno_id</label>
<input type='number' name='campo_aluno_id'><br>
<label for='campo_curso_id'>curso_id</label>
<input type='number' name='campo_curso_id'><br>
<label for='campo_ano_letivo'>ano_letivo</label>
<input type='number' name='campo_ano_letivo'><br>
<button type='submit'>Enviar</button>

        </form>
    </body>
</html>