<html>
    <head>
        <title>Cadastro de estado</title>
    </head>
    <body>
        <form>
            <label for='campo_id'>id</label>
<input type='text' name='campo_id'><br>
<label for='campo_nomeEstado'>nomeEstado</label>
<input type='text' name='campo_nomeEstado'><br>
<label for='campo_sigla'>sigla</label>
<input type='text' name='campo_sigla'><br>
<label for='campo_regiao'>regiao</label>
<input type='text' name='campo_regiao'><br>

        </form>
    </body>
</html>