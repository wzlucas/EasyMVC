<html>
    <head>
        <title>Cadastro de aluno</title>
        <link rel="stylesheet" href="../../css/estilos.css">
    </head>
    <body>
        <form method="POST" action="#">
            <label for='campo_id'>id</label>
<input type='number' name='campo_id'><br>
<label for='campo_nome'>nome</label>
<input type='text' name='campo_nome'><br>
<label for='campo_idade'>idade</label>
<input type='number' name='campo_idade'><br>
<label for='campo_turma'>turma</label>
<input type='text' name='campo_turma'><br>
<button type='submit'>Enviar</button>

        </form>
    </body>
</html>